// Description: This file contains function prototypes to be implemented in
// led.cpp and to be included in main.cpp.
//----------------------------------------------------------------------//

#ifndef LED_H
#define LED_H

void initLED();
void turnOnLEDWithChar(unsigned char num);

#endif
