// Description: This file describes functions used by the timer
//----------------------------------------------------------------------//

#ifndef TIMER_H
#define TIMER_H

void initTimer0();

void delayMs(int delay);

#endif
