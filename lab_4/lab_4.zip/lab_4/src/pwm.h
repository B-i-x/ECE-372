#ifndef PWM_H
#define PWM_H

void initPWMTimer3();
void initPWMTimer4();

void changeDutyCycle(double dutycycle1,double dutycycle2);

void analyzeADC();

#endif