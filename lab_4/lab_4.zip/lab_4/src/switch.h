#ifndef SWITCH_H
#define SWITCH_H

void initSwitchPD0();

#endif
