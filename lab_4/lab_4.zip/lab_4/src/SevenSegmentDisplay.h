#ifndef SEVENSEGMENTDISPLAY_H
#define SEVENSEGMENTDISPLAY_H

void initDisplay();

void WriteToDisplay(int input);

void SER(bool toggle);

#endif